<div class="footer">
		<div class="container">
			 

		<b class="copyright">&copy;Develop by Jothe || MV Supermarket Inventory System|| ©️2021 </b> All rights reserved.
		</div>
	</div>