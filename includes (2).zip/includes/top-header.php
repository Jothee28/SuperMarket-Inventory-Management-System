<?php 
//session_start();

?>

<div class="top-bar animate-dropdown" style=" background-color: black; color:white;">
	<div class="container">
		<div class="header-top-inner">
			<div class="cnt-account">
				<ul class="list-unstyled">

<?php if(strlen($_SESSION['login']))
    {   ?>
				<li><a style=" font-size: 17px;  color:white;" href="#"><i class="icon fa fa-user"></i>Welcome -<?php echo htmlentities($_SESSION['username']);?></a></li>
				<?php } ?>

					<?php if(strlen($_SESSION['login'])==0)
    {   ?>
<li><a style="  color:white; font-size: 17px; " href="index.php"><i class="icon fa fa-sign-in"></i>My Account</a></li>
<?php }
else{ ?>
	
				<li><a style=" font-size: 17px;  color:white;" href="logout.php"><i class="icon fa fa-sign-out"></i>Logout</a></li>
				<?php } ?>	
				</ul>
			</div><!-- /.cnt-account -->

<div class="cnt-block">
				<ul class="list-unstyled list-inline">
					<li class="dropdown dropdown-small">
						<a style=" font-size: 17px; color:white;" href="order-history.php" class="dropdown-toggle" ><span class="key">Track Your Order</b></a>
						
					</li>

				
				</ul>
			</div>
			
			<div class="clearfix"></div>
		</div><!-- /.header-top-inner -->
	</div><!-- /.container -->
</div><!-- /.header-top -->